import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Queue;

public class OperatingSystem
{
	Memory memory;
	PCB pcb;
	Queue<Process> readyQueue;

	public OperatingSystem()
	{
		memory = new Memory(3);
		readyQueue = new LinkedList<Process>();
		System.out.println("=====> Loading Programs <=====");
		this.loadProcess(1);
		this.loadProcess(2);
		this.loadProcess(3);
		System.out.println("=====> Programs Loaded <=====");
		System.out.println("=====> Running the processes <=====");
		this.run();
		System.out.println("=====> Done Running <=====");
	}
	
	private void loadProcess(int proNumber)
	{
		System.out.println("[-] Loading program " + proNumber);
		Process p = new Process();
		p.setInstructions(this.readFile("Program " + proNumber + ".txt"));
		pcb = new PCB(proNumber, 0, p.getInstructions().split("\n").length + 4);
		p.setPcb(pcb.toString());
		this.memory.addProcess(p);
		this.readyQueue.add(p);
		System.out.println("[+] Program " + proNumber + " is loaded successfully");
	}

	public void run()
	{
		while (!readyQueue.isEmpty())
		{
			if (readyQueue.peek().getState().equals("ready") || readyQueue.peek().getState().equals("waiting"))
			{
				System.out.println("=============== Execute Process " + readyQueue.peek().getPcb().split(";")[0] + " ===============");
				readyQueue.peek().run();
				readyQueue.peek().incQuanta();
				if (readyQueue.peek().getState().equals("terminated"))
				{
					System.out.println("=============== Terminated Process " + readyQueue.peek().getPcb().split(";")[0] + " (it took " + readyQueue.peek().getQuanta() + " quanta) ===============");
					readyQueue.poll();
				}
				else
				{
					System.out.println("=============== Pause Process " + readyQueue.peek().getPcb().split(";")[0] + " ===============");
					readyQueue.add(readyQueue.poll());
				}
					
			}
		}
	}

	public String readFile(String fileName)
	{
		String fname1 = "src/" + fileName;

		/* this will reference only one line at a time */
		String line = null;
		String linedata = "";
		try
		{
			/* FileReader reads text files in the default encoding */
			FileReader fileReader = new FileReader(fname1);

			/* always wrap the FileReader in BufferedReader */
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			while ((line = bufferedReader.readLine()) != null)
			{
				linedata = linedata + "\n" + line;

			}

			/* always close the file after use */
			bufferedReader.close();
		} catch (IOException ex)
		{
			System.out.println("Error reading file named '" + fileName + "'");
		}
		return linedata;
	}

	public static void main(String[] args)
	{
		@SuppressWarnings("unused")
		OperatingSystem x = new OperatingSystem();
	}
}
