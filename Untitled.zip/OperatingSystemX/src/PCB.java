
public class PCB
{
	int programCounter;
	String state;
	int processId;
	int lowerBound;
	int upperBound;

	public PCB(int procId, int lb, int ub)
	{
		this.programCounter = 0;
		this.state = "ready";
		this.processId = procId;
		this.lowerBound = lb;
		this.upperBound = ub;
	}

	public String toString()
	{
		return this.processId + ";" + this.programCounter + ";" + this.state + ";" + this.lowerBound + ";"
				+ this.upperBound;
	}

}
