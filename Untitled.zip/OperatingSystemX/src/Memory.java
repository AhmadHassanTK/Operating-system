
public class Memory
{
	Process[] memory;
	int currentProcessCount;
	public Memory(int programCount)
	{
		memory = new Process[programCount];
		currentProcessCount = 0;
	}
	
	public void addProcess(Process p)
	{
		this.memory[currentProcessCount] = p;
		currentProcessCount++;
	}
	
	public String toString()
	{
		String res = "";
		for(int i = 0; i < this.currentProcessCount; i++)
		{
			res += this.memory[i];
			res += "\n========================================\n";
		}
		return res;
	}
}
