import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Process
{
	private String instructions;
	private String pcb;
	private String data;
	private int quanta;

	public Process()
	{
		instructions = "";
		pcb = "";
		data = "";
		quanta = 0;
	}
	
	public int getQuanta()
	{
		return quanta;
	}
	
	public void incQuanta()
	{
		this.quanta++;
	}
	
	public void setInstructions(String instructions)
	{
		this.instructions = instructions;
	}

	public void setData(String data)
	{
		this.data = data;
	}

	public void setPcb(String pcb)
	{
		this.pcb = pcb;
	}

	public String getData()
	{
		return data.trim();
	}

	public String getInstructions()
	{
		return instructions.trim();
	}

	public String getPcb()
	{
		return pcb;
	}

	public String getState()
	{
		return this.getPcb().split(";")[2];
	}

	public void setState(String state)
	{
		String[] p = this.getPcb().split(";");
		p[2] = state;
		this.setPcb(String.join(";", p));
	}

	public void run()
	{
		String[] ins = this.getInstructions().split("\n");
		if (ins.length - this.getProgramCounter() == 1)
		{
			this.execute(ins[this.getProgramCounter()]);
			this.incProgramCounter();
			this.setState("terminated");
		} else if (ins.length - this.getProgramCounter() == 2)
		{
			this.execute(ins[this.getProgramCounter()]);
			this.incProgramCounter();
			this.execute(ins[this.getProgramCounter()]);
			this.incProgramCounter();
			this.setState("terminated");
		} else if (ins.length - this.getProgramCounter() != 0)
		{

			this.execute(ins[this.getProgramCounter()]);
			this.incProgramCounter();
			this.execute(ins[this.getProgramCounter()]);
			this.incProgramCounter();
			this.setState("waiting");

		}
	}

	public int getProgramCounter()
	{
		return Integer.parseInt(this.getPcb().split(";")[1]);
	}

	public void incProgramCounter()
	{
		String[] pcb = this.getPcb().split(";");
		pcb[1] = this.getProgramCounter() + 1 + "";
		this.setPcb(String.join(";", pcb));
	}

	public void execute(String instruction)
	{
		String[] ins = instruction.split(" ");
		if (ins[0].equals("assign"))
			this.assign(ins[1], ins.length == 3 ? ins[2] : ReadFile(ins[3]));
		if (ins[0].equals("print"))
			this.print(ins[1]);
		if (ins[0].equals("add"))
			this.add(ins[1], ins[2]);
		if (ins[0].equals("writeFile"))
			this.WriteFile(ins[1], ins[2]);
	}

	public void print(String varName)
	{
		String data = this.getData();
		if (!data.contains(varName + ":"))
			System.out.print(varName.trim() + " ");
		else
		{
			String[] dataArr = data.split("\n");
			for (int i = 0; i < dataArr.length; i++)
			{
				if (dataArr[i].split(":")[0].equals(varName))
				{
					System.out.println("MEM ACCESS: reading variable " + varName + " and got the value " + dataArr[i].split(":")[1]);
					System.out.println(dataArr[i].split(":")[1]);
					break;
				}
			}
			
		}
	}

	public void add(String a, String b)
	{
		int firstNumber = 0;
		int secondNumber = 0;
		String[] data = this.getData().split("\n");

		for (String x : data)
			if (x.split(":")[0].equals(a))
				firstNumber = Integer.parseInt(x.split(":")[1]);

		for (String x : data)
			if (x.split(":")[0].equals(b))
				secondNumber = Integer.parseInt(x.split(":")[1]);
		
		System.out.println("MEM ACCESS: reading variable " + a + " and got the value " + firstNumber);
		System.out.println("MEM ACCESS: reading variable " + b + " and got the value " + secondNumber);
		int result = firstNumber + secondNumber;

		for (int i = 0; i < data.length; i++)
		{
			if (data[i].split(":")[0].equals(a))
			{
				data[i] = a + ":" + result;
				break;
			}
		}
		this.setData(String.join("\n", data));
		System.out.println("MEM ACCESS: setting " + a + " = " + result);
	}

	public void assign(String varName, String value)
	{
		@SuppressWarnings("resource")
		Scanner In = new Scanner(System.in);
		if (value.equals("input"))
		{
			value = (String) In.next();
			String data = this.getData();
			if (!data.contains(varName + ":"))
			{
				this.setData(this.getData() + "\n" + varName + ":" + value);
				System.out.println("MEM ACCESS: setting " + varName + " = " + value);
			} else
			{
				String dataArr[] = data.split("\n");
				for (int i = 0; i < dataArr.length; i++)
				{
					if (dataArr[i].split(":")[0].equals(varName))
					{
						dataArr[i] = varName + ":" + value;
						break;
					}
				}
				this.setData(String.join("\n", data));
				System.out.println("MEM ACCESS: setting " + varName + " = " + value);
			}
		} else
		{
			String data = this.getData();
			if (!data.contains(varName + ":"))
			{
				this.setData(this.getData() + "\n" + varName + ":" + value);
				System.out.println("MEM ACCESS: setting " + varName + " = " + value);
			} else
			{
				String dataArr[] = data.split("\n");
				for (int i = 0; i < dataArr.length; i++)
				{
					if (dataArr[i].split(":")[0].equals(varName))
					{
						dataArr[i] = varName + ":" + value;
						break;
					}
				}
				this.setData(String.join("\n", data));
				System.out.println("MEM ACCESS: setting " + varName + " = " + value);
			}

		}
	}

	public String ReadFile(String varName)
	{
		String[] data = this.getData().split("\n");
		String fileName = "";
		for (String x : data)
		{
			if (x.split(":")[0].equals(varName))
			{
				fileName = x.split(":")[1];
				break;
			}
		}
		
		System.out.println("MEM ACCESS: reading variable " + varName + " and got the value " + fileName);

		String fname1 = "src/" + fileName;

		/* this will reference only one line at a time */
		String line = null;
		String linedata = "";
		try
		{
			/* FileReader reads text files in the default encoding */
			FileReader fileReader = new FileReader(fname1);

			/* always wrap the FileReader in BufferedReader */
			BufferedReader bufferedReader = new BufferedReader(fileReader);

			while ((line = bufferedReader.readLine()) != null)
			{
				linedata = line.trim();
			}

			/* always close the file after use */
			bufferedReader.close();
		} catch (IOException ex)
		{
			System.out.println("Error reading file named '" + fileName + "'");
		}
		return linedata;

	}

	public void WriteFile(String a, String b)
	{
		String fileName = "";
		String dataToWrite = "";
		String[] data = this.getData().split("\n");
		for (String x : data)
		{
			if (x.split(":")[0].equals(a))
			{
				fileName = x.split(":")[1];
				break;
			}
		}
		
		System.out.println("MEM ACCESS: reading variable " + a + " and got the value " + fileName);

		for (String x : data)
		{
			if (x.split(":")[0].equals(b))
			{
				dataToWrite = x.split(":")[1];
				break;
			}
		}
		System.out.println("MEM ACCESS: reading variable " + b + " and got the value " + dataToWrite);
		
		try
		{
			FileWriter fw = new FileWriter("src/" + fileName, true);
			fw.write("\n" + dataToWrite);
			fw.close();
			System.out.println("File is created successfully with the content fetched from the memory.");
		} catch (IOException e)
		{

			System.out.print(e.getMessage());
		}

	}

	public String toString()
	{
		return "Instruction: " + this.getInstructions() + "\nPCB: " + this.getPcb() + "\nData: " + this.getData();
	}
}
